import React, { useState, useMemo, useRef } from 'react';
import { Hero } from './Hero';
import { CategoryCard } from './CategoryCard';
import { SearchBar } from './SearchBar';
import { FilterBar } from './FilterBar';
import { PromptCard } from './PromptCard';
import { PromptModal } from './PromptModal';
import { Footer } from './Footer';
import { categories } from '../data/categories';
import { allPrompts } from '../data/allPrompts';
import { Prompt, Category, AIModel, Complexity } from '../types/prompt';

export const AppLayout: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedModel, setSelectedModel] = useState<AIModel | 'All'>('All');
  const [selectedComplexity, setSelectedComplexity] = useState<Complexity | 'All'>('All');
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null);
  const libraryRef = useRef<HTMLDivElement>(null);

  const filteredPrompts = useMemo(() => {
    return allPrompts.filter(prompt => {
      const matchesCategory = selectedCategory === 'All' || prompt.category === selectedCategory;
      const matchesSearch = searchQuery === '' || 
        prompt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prompt.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prompt.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesModel = selectedModel === 'All' || 
        prompt.aiModels.includes(selectedModel) || 
        prompt.aiModels.includes('All');
      const matchesComplexity = selectedComplexity === 'All' || prompt.complexity === selectedComplexity;
      
      return matchesCategory && matchesSearch && matchesModel && matchesComplexity;
    });
  }, [selectedCategory, searchQuery, selectedModel, selectedComplexity]);

  const handleExplore = () => {
    libraryRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Hero onExplore={handleExplore} />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Browse by Category</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our curated collection of prompt templates organized by use case
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {categories.map(category => (
            <CategoryCard
              key={category.name}
              category={category}
              onClick={() => {
                setSelectedCategory(category.name);
                handleExplore();
              }}
              isActive={selectedCategory === category.name}
            />
          ))}
        </div>

        {selectedCategory !== 'All' && (
          <div className="text-center">
            <button
              onClick={() => setSelectedCategory('All')}
              className="text-purple-600 hover:text-purple-700 font-medium"
            >
              View All Categories
            </button>
          </div>
        )}
      </section>

      <section ref={libraryRef} className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Prompt Library</h2>
            <p className="text-gray-600">
              {filteredPrompts.length} prompts available
            </p>
          </div>

          <div className="space-y-6 mb-8">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder="Search prompts by name, description, or tags..."
            />
            <FilterBar
              selectedModel={selectedModel}
              onModelChange={setSelectedModel}
              selectedComplexity={selectedComplexity}
              onComplexityChange={setSelectedComplexity}
            />
          </div>

          {filteredPrompts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No prompts found matching your criteria</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                  setSelectedModel('All');
                  setSelectedComplexity('All');
                }}
                className="mt-4 text-purple-600 hover:text-purple-700 font-medium"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPrompts.map(prompt => (
                <PromptCard
                  key={prompt.id}
                  prompt={prompt}
                  onClick={() => setSelectedPrompt(prompt)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />

      {selectedPrompt && (
        <PromptModal
          prompt={selectedPrompt}
          onClose={() => setSelectedPrompt(null)}
        />
      )}
    </div>
  );
};

export default AppLayout;

