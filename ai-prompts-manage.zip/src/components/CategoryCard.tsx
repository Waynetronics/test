import React from 'react';
import { CategoryInfo } from '../types/prompt';

interface CategoryCardProps {
  category: CategoryInfo;
  onClick: () => void;
  isActive: boolean;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ category, onClick, isActive }) => {
  return (
    <button
      onClick={onClick}
      className={`group relative overflow-hidden rounded-xl p-6 text-left transition-all duration-300 ${
        isActive
          ? 'bg-gradient-to-br ' + category.color + ' text-white shadow-lg scale-105'
          : 'bg-white hover:shadow-xl border border-gray-200'
      }`}
    >
      <div className="relative z-10">
        <div className="mb-4 w-12 h-12 rounded-lg overflow-hidden">
          <img 
            src={category.icon} 
            alt={category.name}
            className="w-full h-full object-cover"
          />
        </div>
        <h3 className={`text-lg font-bold mb-2 ${isActive ? 'text-white' : 'text-gray-900'}`}>
          {category.name}
        </h3>
        <p className={`text-sm ${isActive ? 'text-white/90' : 'text-gray-600'}`}>
          {category.description}
        </p>
      </div>
      {!isActive && (
        <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity`} />
      )}
    </button>
  );
};
