import React from 'react';
import { AIModel, Complexity } from '../types/prompt';

interface FilterBarProps {
  selectedModel: AIModel | 'All';
  onModelChange: (model: AIModel | 'All') => void;
  selectedComplexity: Complexity | 'All';
  onComplexityChange: (complexity: Complexity | 'All') => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  selectedModel,
  onModelChange,
  selectedComplexity,
  onComplexityChange
}) => {
  const models: (AIModel | 'All')[] = ['All', 'GPT-4', 'Claude', 'Gemini'];
  const complexities: (Complexity | 'All')[] = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  return (
    <div className="flex flex-wrap gap-4">
      <div className="flex-1 min-w-[200px]">
        <label className="block text-sm font-medium text-gray-700 mb-2">AI Model</label>
        <select
          value={selectedModel}
          onChange={(e) => onModelChange(e.target.value as AIModel | 'All')}
          className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
        >
          {models.map(model => (
            <option key={model} value={model}>{model}</option>
          ))}
        </select>
      </div>
      <div className="flex-1 min-w-[200px]">
        <label className="block text-sm font-medium text-gray-700 mb-2">Complexity</label>
        <select
          value={selectedComplexity}
          onChange={(e) => onComplexityChange(e.target.value as Complexity | 'All')}
          className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
        >
          {complexities.map(complexity => (
            <option key={complexity} value={complexity}>{complexity}</option>
          ))}
        </select>
      </div>
    </div>
  );
};
