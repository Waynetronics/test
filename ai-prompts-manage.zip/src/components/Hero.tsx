import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExplore }) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'url(https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420446819_88023919.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span className="text-sm font-medium">Master AI Communication</span>
          </div>
          
          <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Articulate Perfect Prompts for
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent"> Any AI Model</span>
          </h1>
          
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Discover, customize, and deploy battle-tested prompt templates. Transform your AI interactions with proven frameworks used by top engineers and creators.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <button
              onClick={onExplore}
              className="group inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl font-semibold hover:shadow-2xl hover:scale-105 transition-all"
            >
              Explore Library
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 bg-white/10 backdrop-blur-sm rounded-xl font-semibold hover:bg-white/20 transition-all">
              View Documentation
            </button>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-8">
            <div>
              <div className="text-3xl font-bold mb-1">20+</div>
              <div className="text-gray-400 text-sm">Prompt Templates</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-1">6</div>
              <div className="text-gray-400 text-sm">Categories</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-1">90%+</div>
              <div className="text-gray-400 text-sm">Effectiveness</div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-50 to-transparent" />
    </div>
  );
};
