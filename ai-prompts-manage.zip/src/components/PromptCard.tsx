import React from 'react';
import { Prompt } from '../types/prompt';
import { Badge } from './ui/Badge';
import { RatingStars } from './ui/RatingStars';
import { GitFork, TrendingUp, Eye } from 'lucide-react';

interface PromptCardProps {
  prompt: Prompt;
  onClick: () => void;
}

export const PromptCard: React.FC<PromptCardProps> = ({ prompt, onClick }) => {
  const complexityColors = {
    Beginner: 'green',
    Intermediate: 'orange',
    Advanced: 'purple'
  } as const;

  return (
    <div
      onClick={onClick}
      className="group bg-white rounded-xl border border-gray-200 p-6 hover:shadow-xl hover:border-purple-300 transition-all duration-300 cursor-pointer"
    >
      <div className="flex items-start justify-between mb-3">
        <Badge variant="blue" size="sm">{prompt.category}</Badge>
        <Badge variant={complexityColors[prompt.complexity]} size="sm">
          {prompt.complexity}
        </Badge>
      </div>

      <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-purple-600 transition-colors">
        {prompt.title}
      </h3>
      
      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
        {prompt.description}
      </p>

      <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <GitFork className="w-4 h-4" />
          <span>{prompt.forks}</span>
        </div>
        <div className="flex items-center gap-1">
          <TrendingUp className="w-4 h-4" />
          <span>{prompt.effectiveness}%</span>
        </div>
      </div>

      <RatingStars rating={prompt.rating} size="sm" />

      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex flex-wrap gap-2">
          {prompt.tags.slice(0, 3).map(tag => (
            <Badge key={tag} variant="default" size="sm">
              #{tag}
            </Badge>
          ))}
        </div>
      </div>

      <button className="mt-4 w-full flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
        <Eye className="w-4 h-4" />
        View Details
      </button>
    </div>
  );
};
