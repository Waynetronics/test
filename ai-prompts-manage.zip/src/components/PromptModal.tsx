import React, { useState } from 'react';
import { Prompt } from '../types/prompt';
import { X, GitFork, TrendingUp, User, Tag } from 'lucide-react';
import { Badge } from './ui/Badge';
import { RatingStars } from './ui/RatingStars';
import { CopyButton } from './ui/CopyButton';

interface PromptModalProps {
  prompt: Prompt;
  onClose: () => void;
}

export const PromptModal: React.FC<PromptModalProps> = ({ prompt, onClose }) => {
  const [variables, setVariables] = useState<Record<string, string>>({});

  const handleVariableChange = (varName: string, value: string) => {
    setVariables(prev => ({ ...prev, [varName]: value }));
  };

  const getFilledTemplate = () => {
    let filled = prompt.template;
    Object.entries(variables).forEach(([key, value]) => {
      filled = filled.replace(new RegExp(`{${key}}`, 'g'), value || `{${key}}`);
    });
    return filled;
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{prompt.title}</h2>
            <p className="text-gray-600">{prompt.description}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <RatingStars rating={prompt.rating} />
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <GitFork className="w-4 h-4" />
              <span className="text-sm">{prompt.forks} forks</span>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm">{prompt.effectiveness}% effective</span>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <User className="w-4 h-4" />
              <span className="text-sm">{prompt.author}</span>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3">Prompt Template</h3>
            <div className="bg-gray-900 rounded-lg p-4 relative">
              <pre className="text-sm text-gray-100 font-mono whitespace-pre-wrap overflow-x-auto">
                {prompt.template}
              </pre>
              <div className="absolute top-4 right-4">
                <CopyButton text={prompt.template} />
              </div>
            </div>
          </div>

          {prompt.variables.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3">Variables</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {prompt.variables.map(varName => (
                  <div key={varName}>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {varName}
                    </label>
                    <input
                      type="text"
                      value={variables[varName] || ''}
                      onChange={(e) => handleVariableChange(varName, e.target.value)}
                      placeholder={`Enter ${varName}`}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {Object.keys(variables).length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3">Preview</h3>
              <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4 relative">
                <pre className="text-sm text-gray-800 font-mono whitespace-pre-wrap">
                  {getFilledTemplate()}
                </pre>
                <div className="absolute top-4 right-4">
                  <CopyButton text={getFilledTemplate()} label="Copy Preview" />
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Use Cases</h3>
              <ul className="space-y-2">
                {prompt.useCases.map((useCase, i) => (
                  <li key={i} className="flex items-start gap-2 text-gray-700">
                    <span className="text-purple-600 mt-1">•</span>
                    <span>{useCase}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-3">Compatible AI Models</h3>
              <div className="flex flex-wrap gap-2">
                {prompt.aiModels.map(model => (
                  <Badge key={model} variant="blue">{model}</Badge>
                ))}
              </div>
              <h3 className="text-lg font-semibold mb-3 mt-4">Industries</h3>
              <div className="flex flex-wrap gap-2">
                {prompt.industry.map(ind => (
                  <Badge key={ind} variant="purple">{ind}</Badge>
                ))}
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Tag className="w-5 h-5" />
              Tags
            </h3>
            <div className="flex flex-wrap gap-2">
              {prompt.tags.map(tag => (
                <Badge key={tag} variant="default">#{tag}</Badge>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
