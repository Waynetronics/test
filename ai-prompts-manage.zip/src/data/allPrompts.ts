import { prompts } from './prompts';
import { prompts2 } from './prompts2';
import { prompts3 } from './prompts3';
import { prompts4 } from './prompts4';

export const allPrompts = [...prompts, ...prompts2, ...prompts3, ...prompts4];
