import { CategoryInfo } from '../types/prompt';

export const categories: CategoryInfo[] = [
  {
    name: 'Creative Writing',
    icon: 'https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420447558_a74bf1cf.webp',
    description: 'Craft compelling narratives, poetry, and creative content',
    color: 'from-purple-500 to-pink-500'
  },
  {
    name: 'Code Generation',
    icon: 'https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420448276_63130828.webp',
    description: 'Generate, debug, and optimize code across languages',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    name: 'Analysis',
    icon: 'https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420449076_efe52aba.webp',
    description: 'Deep data analysis, insights, and research synthesis',
    color: 'from-indigo-500 to-purple-500'
  },
  {
    name: 'Conversation Design',
    icon: 'https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420449775_1b5636ed.webp',
    description: 'Build engaging chatbots and conversational interfaces',
    color: 'from-violet-500 to-purple-500'
  },
  {
    name: 'System Instructions',
    icon: 'https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420450477_7c0e4161.webp',
    description: 'Configure AI behavior and system-level parameters',
    color: 'from-blue-600 to-indigo-600'
  },
  {
    name: 'General',
    icon: 'https://d64gsuwffb70l.cloudfront.net/68ede22bd37480a25c906ae0_1760420451185_73e54ef3.webp',
    description: 'Versatile prompts for various everyday tasks',
    color: 'from-purple-600 to-blue-600'
  }
];
