export interface Prompt {
  id: string;
  title: string;
  description: string;
  category: Category;
  template: string;
  variables: string[];
  aiModels: AIModel[];
  complexity: Complexity;
  industry: string[];
  rating: number;
  forks: number;
  effectiveness: number;
  useCases: string[];
  author: string;
  tags: string[];
}

export type Category = 
  | 'Creative Writing'
  | 'Code Generation'
  | 'Analysis'
  | 'Conversation Design'
  | 'System Instructions'
  | 'General';

export type AIModel = 'GPT-4' | 'Claude' | 'Gemini' | 'All';

export type Complexity = 'Beginner' | 'Intermediate' | 'Advanced';

export interface CategoryInfo {
  name: Category;
  icon: string;
  description: string;
  color: string;
}
